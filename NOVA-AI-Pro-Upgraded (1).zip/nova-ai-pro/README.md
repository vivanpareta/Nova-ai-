# NOVA AI Pro — multi-agent workspace starter

A responsive Node.js + HTML/CSS/JS starter with optional OpenAI-compatible LLM integration. It is deliberately honest about provider-dependent capabilities: without an API key, chat and agent endpoints return a clear demo response rather than pretending to have generated real AI output.

## Included

- Responsive web UI: chat, multi-agent, file workspace, memory vault, automation, image/video prompt studio.
- Multi-agent pipeline: planner → research analyst → creator → reviewer. With a configured chat model, these are sequential model calls, not independent autonomous systems.
- Provider-agnostic chat endpoint using an OpenAI-compatible `/chat/completions` API.
- File text extraction: TXT, MD, CSV, JSON, PDF and DOCX (10 MB limit).
- Explicitly saved server-side memory in `data/memory.json`.
- Scheduled text tasks persisted in `data/tasks.json`, plus a manual Run now button.
- Browser-native speech recognition (where supported) and text-to-speech can be added; microphone transcription button is included, while spoken assistant playback is not wired yet.
- Server-persisted chat history (JSON; not multi-user safe without authentication).
- Optional web research using a Tavily-compatible search API plus the configured chat model; reports cite returned search results.
- Optional OpenAI-compatible image generation endpoint.
- Optional video-provider request forwarding; the response shape and polling remain provider-specific. **Actual image/video rendering is not connected by default.**

## Requirements

- Node.js 20+ recommended.
- A provider API key is optional for UI/demo mode and required for real model responses.
- Free-tier availability and quotas vary by provider and can change. No provider is guaranteed to remain free.

## Run locally

1. Extract this project folder.
2. In a terminal, enter the folder:

   ```bash
   cd nova-ai-pro
   npm install
   ```

3. Copy `.env.example` to `.env`.
4. For demo mode, leave the API key blank. For live chat, set an OpenAI-compatible provider URL, key and model in `.env`. For example, an OpenRouter-compatible configuration can use `AI_BASE_URL=https://openrouter.ai/api/v1`; check the provider's current model list and free-tier limits before selecting `AI_MODEL`.
5. Start the app:

   ```bash
   npm start
   ```

6. Open `http://localhost:3000` in your browser.

## Configuration

```env
PORT=3000
AI_BASE_URL=https://openrouter.ai/api/v1
AI_API_KEY=your_key_here
AI_MODEL=your_provider_model_id
TAVILY_API_KEY=your_tavily_key
IMAGE_BASE_URL=https://api.openai.com/v1
IMAGE_API_KEY=your_image_provider_key
IMAGE_MODEL=your_image_model_id
IMAGE_SIZE=1024x1024
VIDEO_API_URL=https://your-video-provider.example/v1/generations
VIDEO_API_KEY=your_video_provider_key
```

Keep `.env` private. Never put provider keys in `public/app.js`, HTML, or any frontend bundle. This starter has no user authentication, so keep it local/private until authentication, rate limits, request validation, CSRF protections, and secure deployment configuration are added. Chat history, memory and tasks are shared JSON files; do not expose this backend publicly as-is.

## Reality check: working vs provider-dependent

| Feature | Status |
|---|---|
| UI navigation and responsive layout | Working locally |
| API status indicator | Working |
| Chat | Demo without key; real LLM response with compatible provider config |
| Multi-agent workflow | Demo without key; sequential role prompts with provider config |
| TXT/MD/CSV/JSON/PDF/DOCX text extraction | Implemented; depends on file format quality |
| Save/delete memory | Working on local server; plain JSON, not encrypted |
| Create/list/delete/run scheduled text tasks | Implemented; server must stay online |
| Voice input | Browser-dependent speech recognition; requires microphone permission |
| Assistant voice playback | Not wired in this starter |
| Chat history | Server-side JSON persistence; no authentication/user isolation yet |
| Deep Research | Tavily-compatible search + LLM synthesis; requires both provider keys; snippets only |
| Image generation | OpenAI-compatible endpoint; requires supported image provider/model |
| Video generation | Provider request forwarding only; likely needs a provider-specific adapter and polling |
| Web browsing, email, app control, purchases, autonomous computer use | Not implemented; requires separate, permissioned integrations |

## Automation limitation

The included scheduler is intentionally a small local starter. It reliably handles common exact-value and wildcard schedules, but not all cron range/step expressions. It runs only while the Node process is running and uses the server's timezone. For dependable production schedules, use a managed scheduler/queue and proper job locking/retries.

## Before public deployment

Add authentication and per-user data isolation; encrypt or protect stored files and memory; limit upload size and content; add rate limiting and request timeouts; add audit logs and deletion controls; add provider spend caps; use HTTPS; validate all automation actions; and require user confirmation before consequential external actions. Do not treat model output as trusted code.


## Deployment note

The app is a Node/Express application, not a static-only Netlify Drop site. Uploading `public/` alone serves the UI but cannot run `/api/*` routes, scheduled tasks, file extraction, or JSON persistence. Deploy the Node server to a Node-compatible host and set the frontend/API base URL appropriately, or port the API routes to Netlify Functions with persistent storage. A filesystem on many serverless hosts is temporary, so JSON-file persistence is not suitable there.
