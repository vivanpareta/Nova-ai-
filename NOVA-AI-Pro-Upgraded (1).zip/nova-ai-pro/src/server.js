import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import multer from 'multer';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cron from 'node-cron';
import pdf from 'pdf-parse/lib/pdf-parse.js';
import mammoth from 'mammoth';

dotenv.config();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const DATA = path.join(ROOT, 'data');
const UPLOADS = path.join(ROOT, 'uploads');
await fs.mkdir(DATA, { recursive: true }); await fs.mkdir(UPLOADS, { recursive: true });
const app = express();
app.use(cors()); app.use(express.json({ limit: '2mb' })); app.use(express.static(path.join(ROOT, 'public')));
const upload = multer({ dest: UPLOADS, limits: { fileSize: 10 * 1024 * 1024 } });
const readJson = async (name, fallback) => { try { return JSON.parse(await fs.readFile(path.join(DATA, name), 'utf8')); } catch { return fallback; } };
const writeJson = async (name, value) => fs.writeFile(path.join(DATA, name), JSON.stringify(value, null, 2));
const clamp = (s, n=16000) => String(s || '').slice(0,n);

async function chat(messages, opts={}) {
  const base = (process.env.AI_BASE_URL || '').replace(/\/$/, '');
  const key = process.env.AI_API_KEY;
  if (!base || !key) return { demo: true, text: 'Demo mode: add AI_BASE_URL, AI_API_KEY, and AI_MODEL to .env, then restart NOVA AI to receive real model responses. Your request was received, but no external AI call was made.' };
  const response = await fetch(`${base}/chat/completions`, { method:'POST', headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json','HTTP-Referer':'http://localhost:3000','X-Title':'NOVA AI'}, body:JSON.stringify({ model: process.env.AI_MODEL, messages, temperature: opts.temperature ?? 0.5 }) });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data?.error?.message || `Provider returned HTTP ${response.status}`);
  return { demo:false, text:data?.choices?.[0]?.message?.content || 'The provider returned an empty response.' };
}
const systemFor = (role) => ({
  planner:'You are NOVA Planner. Turn the user goal into a safe, practical numbered plan. Do not claim actions were executed.',
  researcher:'You are NOVA Research Analyst. Analyze the supplied context, separate facts from assumptions, and disclose when live web access is unavailable. Never invent citations.',
  creator:'You are NOVA Creator. Produce the requested draft, code, or structured output. Be clear and useful.',
  reviewer:'You are NOVA Reviewer. Check the draft for correctness, missing steps, safety, and clarity. Return a concise improved final answer.'
}[role] || 'You are NOVA AI, a helpful multi-purpose assistant. Be accurate, transparent, and concise.');

app.get('/api/status', (_req,res)=>res.json({ ok:true, providerConnected:!!(process.env.AI_BASE_URL && process.env.AI_API_KEY), model:process.env.AI_MODEL || 'not configured', capabilities:{chat:!!process.env.AI_API_KEY, agent:!!process.env.AI_API_KEY, image:!!(process.env.IMAGE_BASE_URL&&process.env.IMAGE_API_KEY&&process.env.IMAGE_MODEL), research:!!process.env.TAVILY_API_KEY, voice:'browser-native', fileText:true, video:!!(process.env.VIDEO_API_URL&&process.env.VIDEO_API_KEY), automation:'local scheduled tasks'} }));
app.post('/api/chat', async (req,res)=>{ try { const text=clamp(req.body?.message,12000).trim(); if(!text) return res.status(400).json({error:'Message is required.'}); const history=Array.isArray(req.body?.history)?req.body.history.slice(-12).map(m=>({role:m.role==='assistant'?'assistant':'user',content:clamp(m.content,3000)})):[]; const result=await chat([{role:'system',content:systemFor('chat')},...history,{role:'user',content:text}]); res.json(result); } catch(e){res.status(502).json({error:e.message});} });
app.post('/api/agent', async (req,res)=>{ try { const goal=clamp(req.body?.goal,8000).trim(); if(!goal)return res.status(400).json({error:'Describe the goal first.'}); const context=clamp(req.body?.context,10000); const steps=[]; let prior=''; for(const role of ['planner','researcher','creator','reviewer']) { const r=await chat([{role:'system',content:systemFor(role)},{role:'user',content:`Goal: ${goal}\nContext: ${context || '(none supplied)'}\n${prior?`Previous stage output:\n${prior}`:''}\nBe transparent: do not claim to browse, run code, send messages, or change external systems unless a connected tool actually did it.`}]); steps.push({agent:role, text:r.text, demo:r.demo}); prior=r.text; if(r.demo) break; } res.json({steps, text:steps.at(-1)?.text || 'No output', demo:steps.some(s=>s.demo)}); }catch(e){res.status(502).json({error:e.message});} });
app.post('/api/upload', upload.single('file'), async(req,res)=>{ let f=req.file; if(!f)return res.status(400).json({error:'Choose a file.'}); try { let text=''; const name=f.originalname.toLowerCase(); if(name.endsWith('.txt')||name.endsWith('.md')||name.endsWith('.csv')||name.endsWith('.json')) text=await fs.readFile(f.path,'utf8'); else if(name.endsWith('.pdf')) {const parsed=await pdf(await fs.readFile(f.path)); text=parsed.text;} else if(name.endsWith('.docx')) {const parsed=await mammoth.extractRawText({path:f.path}); text=parsed.value;} else return res.status(415).json({error:'Supported file types: TXT, MD, CSV, JSON, PDF, DOCX.'}); res.json({name:f.originalname, text:clamp(text,30000), chars:text.length}); } catch(e){res.status(400).json({error:`Could not read file: ${e.message}`});} finally {await fs.unlink(f.path).catch(()=>{});} });
app.get('/api/memory', async(_req,res)=>res.json(await readJson('memory.json',[])));
app.post('/api/memory', async(req,res)=>{ const text=clamp(req.body?.text,1500).trim(); if(!text)return res.status(400).json({error:'Memory text is required.'}); const items=await readJson('memory.json',[]); const item={id:Date.now().toString(36),text,createdAt:new Date().toISOString()}; items.unshift(item); await writeJson('memory.json',items.slice(0,100)); res.json(item); });
app.delete('/api/memory/:id',async(req,res)=>{const items=await readJson('memory.json',[]);await writeJson('memory.json',items.filter(x=>x.id!==req.params.id));res.json({ok:true});});
app.get('/api/tasks',async(_req,res)=>res.json(await readJson('tasks.json',[])));
app.post('/api/tasks',async(req,res)=>{const title=clamp(req.body?.title,180).trim(),prompt=clamp(req.body?.prompt,2000).trim(),schedule=clamp(req.body?.schedule,100);if(!title||!prompt||!schedule)return res.status(400).json({error:'Title, prompt and schedule are required.'});if(!cron.validate(schedule))return res.status(400).json({error:'Invalid cron expression. Example: 0 9 * * 1-5'});const tasks=await readJson('tasks.json',[]);const task={id:Date.now().toString(36),title,prompt,schedule,enabled:true,createdAt:new Date().toISOString(),lastRun:null,lastResult:null};tasks.unshift(task);await writeJson('tasks.json',tasks);res.json(task);});
app.post('/api/tasks/:id/run',async(req,res)=>{const tasks=await readJson('tasks.json',[]);const t=tasks.find(x=>x.id===req.params.id);if(!t)return res.status(404).json({error:'Task not found.'});try{const result=await chat([{role:'system',content:'You are NOVA Automation. Carry out only the text-generation task described. Do not claim external actions.'},{role:'user',content:t.prompt}]);t.lastRun=new Date().toISOString();t.lastResult=result.text;await writeJson('tasks.json',tasks);res.json({text:result.text,demo:result.demo});}catch(e){res.status(502).json({error:e.message});}});
app.delete('/api/tasks/:id',async(req,res)=>{const tasks=await readJson('tasks.json',[]);await writeJson('tasks.json',tasks.filter(x=>x.id!==req.params.id));res.json({ok:true});});
// Local scheduler: tasks run only while this server process is running.
cron.schedule('* * * * *',async()=>{const tasks=await readJson('tasks.json',[]);for(const t of tasks.filter(x=>x.enabled&&cron.validate(x.schedule)&&cronMatchNow(x.schedule))){try{const r=await chat([{role:'system',content:'You are NOVA Automation. Perform only the requested text task; do not claim external actions.'},{role:'user',content:t.prompt}]);t.lastRun=new Date().toISOString();t.lastResult=r.text;}catch(e){t.lastRun=new Date().toISOString();t.lastResult='Error: '+e.message;}}await writeJson('tasks.json',tasks);});
function cronMatchNow(expr){ // minute-level scheduler; support common 5-field cron patterns via node-cron itself is not introspectable
  // This lightweight matcher supports exact minute/hour and wildcard fields; advanced schedules may need a dedicated scheduler.
  const p=expr.trim().split(/\s+/);if(p.length!==5)return false;const d=new Date();const vals=[d.getMinutes(),d.getHours(),d.getDate(),d.getMonth()+1,d.getDay()];return p.every((part,i)=>part==='*'||part.split(',').some(v=>v===String(vals[i])));
}

// Chat history is stored on this server as JSON. Add authentication before using with multiple users.
app.get('/api/chats', async (_req,res)=>res.json(await readJson('chats.json',[])));
app.post('/api/chats', async (req,res)=>{
  const title=clamp(req.body?.title,120).trim()||'New conversation';
  const messages=Array.isArray(req.body?.messages)?req.body.messages.slice(-80).map(m=>({role:m.role==='assistant'?'assistant':'user',content:clamp(m.content,12000),at:m.at||new Date().toISOString()})):[];
  const chats=await readJson('chats.json',[]); const id=clamp(req.body?.id,80).trim()||Date.now().toString(36);
  const item={id,title,messages,updatedAt:new Date().toISOString()}; const idx=chats.findIndex(c=>c.id===id);
  if(idx>=0) chats[idx]=item; else chats.unshift(item); await writeJson('chats.json',chats.slice(0,100)); res.json(item);
});
app.get('/api/chats/:id', async(req,res)=>{const chats=await readJson('chats.json',[]);const item=chats.find(c=>c.id===req.params.id);if(!item)return res.status(404).json({error:'Conversation not found.'});res.json(item)});
app.delete('/api/chats/:id',async(req,res)=>{const chats=await readJson('chats.json',[]);await writeJson('chats.json',chats.filter(c=>c.id!==req.params.id));res.json({ok:true})});

// Optional Deep Research: Tavily performs web search; the configured chat model synthesizes cited results.
app.post('/api/research',async(req,res)=>{
  try {
    const query=clamp(req.body?.query,1500).trim(); if(!query)return res.status(400).json({error:'Enter a research question.'});
    if(!process.env.TAVILY_API_KEY)return res.status(503).json({error:'Deep Research needs TAVILY_API_KEY in the server environment. Add a search provider key, then restart the server.'});
    const sr=await fetch('https://api.tavily.com/search',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({api_key:process.env.TAVILY_API_KEY,query,search_depth:'advanced',max_results:8,include_answer:false,include_raw_content:false})});
    const sd=await sr.json().catch(()=>({})); if(!sr.ok)throw new Error(sd?.message||`Search provider HTTP ${sr.status}`);
    const sources=(sd.results||[]).map((x,i)=>({n:i+1,title:clamp(x.title,300),url:clamp(x.url,1000),content:clamp(x.content,1800),score:x.score}));
    if(!sources.length)return res.json({query,report:'No usable web results were returned. Try a more specific question.',sources:[]});
    const context=sources.map(x=>`[${x.n}] ${x.title}\nURL: ${x.url}\nSnippet: ${x.content}`).join('\n\n');
    const report=await chat([{role:'system',content:'You are NOVA Deep Research. Produce a structured research report with executive summary, key findings, nuance/counterpoints, conclusion, and numbered source references [1], [2] matching ONLY the supplied source list. Distinguish source-supported facts from inference. Never invent citations or claim full coverage.'},{role:'user',content:`Research question: ${query}\n\nSearch results (snippets, not full articles):\n${context}\n\nUse inline citations [n] and finish with a short Sources list using the exact URLs supplied.`}]);
    res.json({query,report:report.text,sources:sources.map(({n,title,url,content})=>({n,title,url,content})),demo:report.demo,coverageNote:'This report summarizes web-search snippets; verify important claims by opening the original sources.'});
  }catch(e){res.status(502).json({error:e.message})}
});

// OpenAI-compatible image generation endpoint. Provider and model availability vary.
app.post('/api/image',async(req,res)=>{
  try {
    const prompt=clamp(req.body?.prompt,4000).trim(); if(!prompt)return res.status(400).json({error:'Image prompt is required.'});
    if(!process.env.IMAGE_BASE_URL||!process.env.IMAGE_API_KEY||!process.env.IMAGE_MODEL)return res.status(503).json({error:'Image rendering is not configured. Set IMAGE_BASE_URL, IMAGE_API_KEY and IMAGE_MODEL on the backend.'});
    const base=process.env.IMAGE_BASE_URL.replace(/\/$/,'');
    const r=await fetch(`${base}/images/generations`,{method:'POST',headers:{Authorization:`Bearer ${process.env.IMAGE_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.IMAGE_MODEL,prompt,n:1,size:process.env.IMAGE_SIZE||'1024x1024',response_format:'url'})});
    const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d?.error?.message||`Image provider HTTP ${r.status}`);
    const item=d.data?.[0];if(!item?.url&&!item?.b64_json)throw new Error('Provider response did not include an image URL or base64 image.');
    res.json({url:item.url||null,b64_json:item.b64_json||null,revised_prompt:item.revised_prompt||null});
  }catch(e){res.status(502).json({error:e.message})}
});

// Video APIs are not standardized. This endpoint forwards a documented prompt payload to a provider you configure.
app.post('/api/video',async(req,res)=>{
  try {
    const prompt=clamp(req.body?.prompt,4000).trim();if(!prompt)return res.status(400).json({error:'Video prompt is required.'});
    if(!process.env.VIDEO_API_URL||!process.env.VIDEO_API_KEY)return res.status(503).json({error:'Video rendering is not configured. Set VIDEO_API_URL and VIDEO_API_KEY for a compatible provider adapter.'});
    const payload={prompt,duration:Number(req.body?.duration)||5,aspect_ratio:clamp(req.body?.aspect_ratio,20)||'16:9'};
    const r=await fetch(process.env.VIDEO_API_URL,{method:'POST',headers:{Authorization:`Bearer ${process.env.VIDEO_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d?.error?.message||d?.message||`Video provider HTTP ${r.status}`);
    res.json({providerResponse:d,note:'Video API response passed through. Polling or result normalization may need a provider-specific adapter.'});
  }catch(e){res.status(502).json({error:e.message})}
});

const port=Number(process.env.PORT||3000);app.listen(port,()=>console.log(`NOVA AI ready at http://localhost:${port}`));
